"""知识库数据面配置；WDT 数据库仅在单据清洗/索引时需要。"""

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class DatabaseSettings:
    host: str
    port: int
    user: str
    password: str
    name: str


@dataclass(frozen=True)
class Settings:
    app_env: str
    mart_database: DatabaseSettings
    wdt_database: DatabaseSettings | None = None

    @classmethod
    def from_environment(cls, environ=None):
        env = os.environ if environ is None else environ
        required = (
            "APP_ENV",
            "PUBLIC_DATA_RDS_HOST",
            "PUBLIC_DATA_RDS_PORT",
            "PUBLIC_DATA_RDS_USER",
            "PUBLIC_DATA_RDS_PASSWORD",
            "PUBLIC_DATA_MART_DATABASE",
        )
        missing = [key for key in required if not (env.get(key) or "").strip()]
        if missing:
            raise ValueError("Missing vector knowledge-base settings: " + ", ".join(missing))
        app_env = env["APP_ENV"].strip()
        if app_env not in ("test", "production"):
            raise ValueError("APP_ENV must be either 'test' or 'production'")
        port_text = env["PUBLIC_DATA_RDS_PORT"].strip()
        if not port_text.isdecimal() or not 1 <= int(port_text) <= 65535:
            raise ValueError("PUBLIC_DATA_RDS_PORT must be a valid TCP port")
        host = env["PUBLIC_DATA_RDS_HOST"].strip()
        user = env["PUBLIC_DATA_RDS_USER"].strip()
        password = env["PUBLIC_DATA_RDS_PASSWORD"]

        def database(name):
            if app_env == "test" and not name.endswith("_test"):
                raise ValueError("test environment requires a *_test database")
            if app_env == "production" and name.endswith("_test"):
                raise ValueError("production environment rejects a *_test database")
            return DatabaseSettings(host, int(port_text), user, password, name)

        mart_name = env["PUBLIC_DATA_MART_DATABASE"].strip()
        wdt_name = (env.get("PUBLIC_DATA_WDT_DATABASE") or "").strip()
        return cls(
            app_env=app_env,
            mart_database=database(mart_name),
            wdt_database=database(wdt_name) if wdt_name else None,
        )

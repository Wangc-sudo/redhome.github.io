"""小易外部发送与知识同步的显式运行门禁。"""


class LiveRunRejected(RuntimeError):
    pass


def _require_confirmation(settings, confirm_local_test_write):
    if confirm_local_test_write is not True:
        raise LiveRunRejected("--confirm-local-test-write is required")
    database = settings.mart_database
    if settings.app_env == "test" and not database.name.endswith("_test"):
        raise LiveRunRejected("test runs require a *_test database")
    if settings.app_env == "production" and database.name.endswith("_test"):
        raise LiveRunRejected("production runs reject a *_test database")


def require_gateway_run(settings, *, live_send, confirm_local_test_write,
                        environ=None, stalled=None):
    if live_send is not True:
        raise LiveRunRejected("--live-send is required")
    _require_confirmation(settings, confirm_local_test_write)


def require_business_run(settings, *, confirm_local_test_write, environ=None):
    _require_confirmation(settings, confirm_local_test_write)


def require_live_run(settings, *, live_read, confirm_local_test_write,
                     environ=None, stalled=None):
    if live_read is not True:
        raise LiveRunRejected("--live-read is required")
    _require_confirmation(settings, confirm_local_test_write)

"""知识库同步所需的钉钉客户端。"""

from vector_kb.dingtalk.client import DingTalkClient, DingTalkError, send_markdown

__all__ = ["DingTalkClient", "DingTalkError", "send_markdown"]

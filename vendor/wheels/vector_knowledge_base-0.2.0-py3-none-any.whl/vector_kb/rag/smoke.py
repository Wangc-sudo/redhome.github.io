# -*- coding: utf-8 -*-
"""RAG 部署冒烟：离线固定向量与在线真实文档检索。"""

import argparse
import importlib.metadata
import json
import os
import tempfile
import time
from pathlib import Path

from vector_kb.kb_qa import rag_docs
from vector_kb.rag import embed, store

DEFAULT_ONLINE_QUERY = "售后退款处理流程"


class SmokeError(RuntimeError):
    def __init__(self, stage, message):
        super().__init__(message)
        self.stage = stage


def _versions():
    result = {}
    for package in ("setuptools", "pymilvus", "milvus-lite"):
        try:
            result[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            result[package] = None
    return result


def _close(client):
    if client is not None:
        client.close()


def offline():
    """用固定二维向量真实执行建库、写入、检索和连接释放。"""
    started = time.perf_counter()
    with tempfile.TemporaryDirectory(prefix="rag-smoke-") as directory:
        client = None
        try:
            client = store.connect(str(Path(directory) / "smoke.db"))
            store.ensure_collection(client, 2)
            items = [
                {
                    "id": "smoke:known",
                    "vector": [1.0, 0.0],
                    "kind": "text",
                    "name": "known",
                    "text": "fixed vector fixture",
                    "image_ref": "",
                },
                {
                    "id": "smoke:other",
                    "vector": [0.0, 1.0],
                    "kind": "text",
                    "name": "other",
                    "text": "orthogonal fixture",
                    "image_ref": "",
                },
            ]
            store.upsert_items(client, items)
            hits = store.search(client, [1.0, 0.0], limit=2, kind="text")
            if not hits or hits[0].get("id") != "smoke:known":
                raise SmokeError("retrieval", "offline_known_id_miss")
            result = {
                "written": len(items),
                "hits": len(hits),
                "top_id": hits[0].get("id"),
                "top_score": hits[0].get("score"),
            }
        except SmokeError:
            raise
        except Exception as exc:
            raise SmokeError("store", type(exc).__name__) from exc
        finally:
            try:
                _close(client)
            except Exception as exc:
                raise SmokeError("store_close", type(exc).__name__) from exc
    result["elapsed_ms"] = round((time.perf_counter() - started) * 1000, 1)
    return result


def _online_store(path):
    client = None
    try:
        client = store.connect(path)
        return store.count(client)
    except Exception as exc:
        raise SmokeError("store", type(exc).__name__) from exc
    finally:
        try:
            _close(client)
        except Exception as exc:
            raise SmokeError("store_close", type(exc).__name__) from exc


def online(query=DEFAULT_ONLINE_QUERY, environ=None):
    """分别验收配置、Milvus、embedding、原始召回和公开检索入口。"""
    values = os.environ if environ is None else environ
    started = time.perf_counter()
    if rag_docs.from_environment(values) is None:
        raise SmokeError("disabled", "rag_environment_incomplete")

    provider = values.get("RAG_EMBED_PROVIDER", embed.DEFAULT_PROVIDER)
    api_key = values.get("RAG_EMBED_API_KEY") or values.get("JINA_API_KEY")
    model = (values.get("RAG_EMBED_MODEL") or values.get("JINA_CLIP_MODEL")
             or embed.default_model(provider))
    dim_text = values.get("RAG_EMBED_DIM") or values.get("JINA_CLIP_DIM")
    dimensions = int(dim_text) if dim_text else None
    path = values.get("RAG_MILVUS_PATH", store.DEFAULT_PATH)
    checks = {}

    stage_started = time.perf_counter()
    checks["store"] = {
        "entries": _online_store(path),
        "elapsed_ms": round((time.perf_counter() - stage_started) * 1000, 1),
    }

    stage_started = time.perf_counter()
    try:
        vector = embed.embed_text(
            query, api_key, model=model, dimensions=dimensions,
            provider=provider, base_url=values.get("RAG_EMBED_BASE_URL"),
        )
    except Exception as exc:
        raise SmokeError("embedding", type(exc).__name__) from exc
    checks["embedding"] = {
        "model": model,
        "dim": len(vector),
        "elapsed_ms": round((time.perf_counter() - stage_started) * 1000, 1),
    }

    stage_started = time.perf_counter()
    client = None
    try:
        client = store.connect(path)
        raw_hits = store.search(client, vector, limit=3, kind="text")
    except Exception as exc:
        raise SmokeError("store_search", type(exc).__name__) from exc
    finally:
        try:
            _close(client)
        except Exception as exc:
            raise SmokeError("store_close", type(exc).__name__) from exc
    checks["raw_search"] = {
        "hits": len(raw_hits),
        "max_score": max((hit.get("score") or 0 for hit in raw_hits), default=0),
        "elapsed_ms": round((time.perf_counter() - stage_started) * 1000, 1),
    }
    if not raw_hits:
        raise SmokeError("unavailable", "production_index_empty")
    if checks["raw_search"]["max_score"] < rag_docs.MIN_TEXT_SCORE:
        raise SmokeError("low_score", "raw_hits_below_threshold")

    stage_started = time.perf_counter()
    try:
        hits = rag_docs.search_vector(
            query, provider=provider, api_key=api_key, environ=values, limit=3,
        )
    except Exception as exc:
        raise SmokeError("search_vector", type(exc).__name__) from exc
    checks["search_vector"] = {
        "hits": len(hits),
        "elapsed_ms": round((time.perf_counter() - stage_started) * 1000, 1),
    }
    if not hits:
        raise SmokeError("low_score", "search_vector_no_accepted_hit")

    return {
        "query": query,
        "checks": checks,
        "hits": [
            {
                "doc_title": hit.get("doc_title"),
                "chunk_index": hit.get("chunk_index"),
                "score": hit.get("score"),
            }
            for hit in hits
        ],
        "elapsed_ms": round((time.perf_counter() - started) * 1000, 1),
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("offline", "online"), default="offline",
                        nargs="?")
    parser.add_argument("--query", default=DEFAULT_ONLINE_QUERY)
    args = parser.parse_args(argv)
    try:
        details = offline() if args.mode == "offline" else online(args.query)
        payload = {"status": "ok", "mode": args.mode, "versions": _versions(),
                   **details}
        print(json.dumps(payload, ensure_ascii=False, sort_keys=True))
        return 0
    except Exception as exc:
        stage = exc.stage if isinstance(exc, SmokeError) else "unknown"
        payload = {
            "status": "failed",
            "mode": args.mode,
            "stage": stage,
            "error_type": type(exc).__name__,
            "versions": _versions(),
        }
        print(json.dumps(payload, ensure_ascii=False, sort_keys=True))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

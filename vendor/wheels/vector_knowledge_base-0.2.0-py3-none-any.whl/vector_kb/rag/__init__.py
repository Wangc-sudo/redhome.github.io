"""独立 RAG 核心：embedding、Milvus Lite、文档/商品/WDT 索引与检索。

生产维度以 `python -m vector_kb.rag.smoke online` 的真实返回为准；建库后维度不可变。
"""

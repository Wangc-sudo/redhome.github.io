# -*- coding: utf-8 -*-
"""独立知识库的最小版本化 MySQL 迁移入口。"""

import argparse
import contextlib
import hashlib

from vector_kb.kb_qa import schema
from vector_kb.public_data import db
from vector_kb.public_data.freshness_repository import ddl_statements as freshness_ddl
from vector_kb.public_data.live_safety import require_business_run
from vector_kb.public_data.settings import Settings
from vector_kb.rag import index_state

LEDGER_TABLE = "vector_knowledge_schema_migration"
MIGRATIONS = (
    ("vector-knowledge-base-tables-v1", schema.kb_ddl_statements()),
    ("vector-knowledge-base-index-state-v1", index_state.ddl_statements()),
    ("vector-knowledge-base-freshness-v1", freshness_ddl()[1:]),
)

_LEDGER_DDL = """CREATE TABLE IF NOT EXISTS `vector_knowledge_schema_migration` (
  `version` VARCHAR(128) NOT NULL,
  `checksum` CHAR(64) NOT NULL,
  `executed_at` DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"""


def _checksum(statements):
    return hashlib.sha256("\n".join(statements).encode("utf-8")).hexdigest()


def apply_migrations(connection):
    """应用未执行版本；已登记版本的 DDL 校验和变化时拒绝继续。"""
    with contextlib.closing(connection.cursor()) as cursor:
        cursor.execute(_LEDGER_DDL)
        cursor.execute(f"SELECT `version`, `checksum` FROM `{LEDGER_TABLE}`")
        applied_rows = cursor.fetchall()
    applied = {
        row["version"]: row["checksum"] if isinstance(row, dict) else row[0]
        for row in applied_rows
    } if applied_rows and isinstance(applied_rows[0], dict) else {
        row[0]: row[1] for row in applied_rows
    }
    result = {"applied": [], "skipped": []}
    with db.transaction(connection):
        with contextlib.closing(connection.cursor()) as cursor:
            for version, statements in MIGRATIONS:
                checksum = _checksum(statements)
                if version in applied:
                    if applied[version] != checksum:
                        raise RuntimeError(f"migration checksum drift: {version}")
                    result["skipped"].append(version)
                    continue
                for statement in statements:
                    cursor.execute(statement)
                cursor.execute(
                    f"INSERT INTO `{LEDGER_TABLE}` (`version`, `checksum`) VALUES (%s, %s)",
                    (version, checksum),
                )
                result["applied"].append(version)
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description="初始化/升级独立知识库 MySQL 表")
    parser.add_argument("--confirm-local-test-write", action="store_true")
    args = parser.parse_args(argv)
    settings = Settings.from_environment()
    require_business_run(
        settings, confirm_local_test_write=args.confirm_local_test_write,
    )
    connection = db.connect(settings.mart_database)
    try:
        result = apply_migrations(connection)
    finally:
        connection.close()
    print(
        "migration applied=" + str(len(result["applied"]))
        + " skipped=" + str(len(result["skipped"]))
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

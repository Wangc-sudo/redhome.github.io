# -*- coding: utf-8 -*-
"""知识库同步所需的最小 MySQL DDL，不包含问答应用或 Web 授权表。"""

_KB_PRODUCTS_DDL = """CREATE TABLE IF NOT EXISTS `kb_products` (
  `record_id` varchar(64) NOT NULL COMMENT '钉钉 AI 表 recordId（幂等 upsert 键）',
  `code` varchar(64) NULL COMMENT '商品编码',
  `name` varchar(255) NOT NULL COMMENT '货品名称',
  `brand` varchar(64) NULL COMMENT '品牌',
  `category` varchar(64) NULL COMMENT '大类',
  `box_qty` int NULL COMMENT '箱规',
  `case_qty` int NULL COMMENT '盒规',
  `size_mm` varchar(64) NULL COMMENT '单盒尺寸(mm)',
  `weight_kg` decimal(10,3) NULL COMMENT '重量(kg)',
  `material` varchar(64) NULL,
  `gift_bag_spec` varchar(128) NULL COMMENT '礼袋规格',
  `barcode_single` varchar(64) NULL COMMENT '单品69码',
  `barcode_case` varchar(64) NULL COMMENT '原箱69码',
  `attachments` json NULL COMMENT '附件元信息 {字段名:[{name,size,mime}]}，URL 用时现取',
  `extra` json NULL COMMENT '其余未映射字段兜底',
  `synced_at` datetime NOT NULL,
  PRIMARY KEY (`record_id`),
  KEY `idx_kb_products_name` (`name`),
  KEY `idx_kb_products_brand` (`brand`, `category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"""

_KB_MEDIA_CACHE_DDL = """CREATE TABLE IF NOT EXISTS `kb_media_cache` (
  `cache_key` varchar(128) NOT NULL COMMENT 'record_id:字段名:序号',
  `media_id` varchar(255) NOT NULL,
  `media_type` varchar(16) NOT NULL COMMENT 'image/file',
  `file_name` varchar(255) NULL,
  `expires_at` datetime NOT NULL COMMENT '钉钉 media_id 3 天有效，提前 1 小时作废',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`cache_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"""

_KB_DOC_CHUNKS_DDL = """CREATE TABLE IF NOT EXISTS `kb_doc_chunks` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `doc_id` varchar(64) NOT NULL COMMENT '钉钉知识库 nodeId',
  `doc_title` varchar(255) NULL,
  `chunk_index` int NOT NULL,
  `content` text NOT NULL,
  `embedding` blob NULL COMMENT 'float32 小端字节序（全量读出内存余弦）',
  `synced_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_kb_doc_chunks_doc` (`doc_id`, `chunk_index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"""


def kb_ddl_statements():
    """返回商品、媒体缓存与 BM25 文档切片的幂等建表语句。"""
    return (_KB_PRODUCTS_DDL, _KB_MEDIA_CACHE_DDL, _KB_DOC_CHUNKS_DDL)

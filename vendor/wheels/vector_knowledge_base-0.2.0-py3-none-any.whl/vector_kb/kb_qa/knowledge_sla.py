"""知识索引 SLA 的独立判定，供知识同步任务使用。"""

from datetime import timedelta, timezone

_BJT = timezone(timedelta(hours=8))
_STATUSES = {"fresh", "degraded", "stale", "blocked", "unknown"}


def _as_utc(value):
    if value is None:
        return None
    if value.tzinfo is not None:
        return value.astimezone(timezone.utc).replace(tzinfo=None)
    return value


def evaluate_knowledge_sla(item, contract, now):
    if not item:
        return "unknown", "not_checked"
    status = item.get("status")
    status = status if status in _STATUSES else "unknown"
    reference = _as_utc(item.get("checked_at") or item.get("last_success_at"))
    if reference is None:
        return "unknown", item.get("last_error") or "not_checked"
    lag_minutes = max(0, int((now - reference).total_seconds() // 60))
    parts = contract.schedule.strip().split()
    hourly = len(parts) >= 2 and parts[0].isdigit() and parts[1] == "*"
    if hourly:
        overdue = lag_minutes > contract.max_lag_minutes
    else:
        bj_now = now.replace(tzinfo=timezone.utc).astimezone(_BJT)
        expected_bj = bj_now.replace(
            hour=contract.expected_by.hour,
            minute=contract.expected_by.minute,
            second=0,
            microsecond=0,
        )
        if expected_bj > bj_now:
            expected_bj -= timedelta(days=1)
        expected_utc = expected_bj.astimezone(timezone.utc).replace(tzinfo=None)
        day_start = expected_bj.replace(
            hour=0, minute=0, second=0, microsecond=0,
        ).astimezone(timezone.utc).replace(tzinfo=None)
        overdue = (
            now > expected_utc + timedelta(minutes=contract.max_lag_minutes)
            and reference < day_start
        )
    if overdue:
        return "stale", "exceeded_max_lag"
    if status == "blocked":
        return status, item.get("last_error") or "blocked"
    if status == "fresh":
        return status, None
    return status, item.get("last_error") or status

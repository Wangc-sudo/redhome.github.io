"""vector-knowledge-base 的兼容导入命名空间。"""
